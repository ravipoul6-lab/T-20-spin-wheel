
// [name, country, M, Runs, BatAvg, SR, Wkts, BowlAvg, Econ, Catches] (approximate career T20I figures)
export const RAW=[
["Virat Kohli","IND",125,4188,48.7,137.0,4,50.3,8.8,56],["Rohit Sharma","IND",159,4231,32.1,140.9,1,13.0,7.0,65],
["Suryakumar Yadav","IND",90,2598,37.1,167.7,0,null,null,25],["Jasprit Bumrah","IND",70,26,6.5,90,89,17.7,6.3,15],
["Hardik Pandya","IND",110,1800,26.1,140.1,94,27.1,8.4,45],["Rashid Khan","AFG",100,600,12.0,140.0,161,13.9,6.1,30],
["Mohammad Nabi","AFG",100,1800,22.0,135.0,70,23.4,7.5,50],["Babar Azam","PAK",128,4223,41.0,129.2,0,null,null,55],
["Mohammad Rizwan","PAK",106,3313,49.0,127.9,0,null,null,60],["Shaheen Afridi","PAK",60,50,7.0,110,100,20.0,8.1,15],
["Jos Buttler","ENG",144,3457,35.3,144.1,0,null,null,75],["Jofra Archer","ENG",30,50,10.0,130,46,20.6,7.4,8],
["Phil Salt","ENG",60,1800,32.0,165.0,0,null,null,20],["Glenn Maxwell","AUS",120,2500,28.1,155.6,42,32.0,8.2,65],
["David Warner","AUS",110,3277,33.4,142.5,0,null,null,38],["Mitchell Starc","AUS",65,90,10.0,110,79,23.0,7.7,10],
["Adam Zampa","AUS",100,140,9.0,115,130,20.0,7.6,25],["Kane Williamson","NZ",93,2575,33.4,125.3,3,40.0,8.0,45],
["Trent Boult","NZ",61,60,7.0,100,83,22.5,7.9,15],["Tim Southee","NZ",126,300,10.0,130,164,22.6,8.2,40],
["Quinton de Kock","SA",92,2600,26.5,138.0,0,null,null,70],["Kagiso Rabada","SA",65,100,8.0,120,80,21.5,7.7,10],
["Heinrich Klaasen","SA",58,1200,30.0,155.0,0,null,null,25],["Nicholas Pooran","WI",100,2200,25.6,135.0,0,null,null,35],
["Andre Russell","WI",84,1100,24.0,168.0,60,22.0,9.0,35],["Sunil Narine","WI",55,250,9.0,120.0,55,20.5,6.0,20],
["Shakib Al Hasan","BAN",129,2551,23.3,123.0,149,20.5,7.0,55],["Wanindu Hasaranga","SL",62,700,17.0,145.0,100,15.5,7.4,30],
["Sikandar Raza","ZIM",100,2400,25.0,140.0,60,25.0,7.4,35],["Paul Stirling","IRE",130,3500,28.5,136.0,15,28.0,7.8,60],
["Chris Gayle","WI",79,1899,23.0,137.1,0,null,null,42],["AB de Villiers","SA",78,1672,26.1,135.2,0,null,null,25],
["Lasith Malinga","SL",84,100,5.0,110.0,107,20.8,7.4,15],["MS Dhoni","IND",98,1617,37.6,126.1,0,null,null,57],
["Shane Watson","AUS",58,1462,29.2,145.0,48,21.0,8.0,20],["Aaron Finch","AUS",103,3120,34.3,142.5,0,null,null,55],
["Eoin Morgan","ENG",115,2458,28.2,136.2,0,null,null,55],["Ben Stokes","ENG",43,585,19.5,132.0,25,27.0,8.5,22],
["Moeen Ali","ENG",92,1229,19.5,140.0,43,26.7,8.2,32],["Kieron Pollard","WI",101,1569,26.6,140.8,42,29.0,9.0,50],
["Dwayne Bravo","WI",91,1245,20.0,115.0,78,24.3,8.2,40],["Faf du Plessis","SA",50,1528,31.2,134.0,0,null,null,25],
["David Miller","SA",115,2200,30.0,140.0,0,null,null,55],["Mahmudullah","BAN",141,2444,22.3,116.0,17,35.0,8.2,60],
["Mustafizur Rahman","BAN",100,30,5.0,90.0,120,18.5,7.5,10],["KL Rahul","IND",72,2265,37.8,139.1,0,null,null,32],
["Yuzvendra Chahal","IND",80,80,5.0,90.0,96,25.1,8.1,20],["Ravindra Jadeja","IND",74,515,21.5,127.2,54,29.9,7.3,26],
["Bhuvneshwar Kumar","IND",87,100,6.7,105.0,90,23.1,6.9,20],["Arshdeep Singh","IND",63,25,5.0,90.0,99,18.2,8.2,10],
["Marcus Stoinis","AUS",66,1000,26.0,145.0,40,28.0,8.6,30],["Pat Cummins","AUS",60,130,10.0,120.0,70,23.5,8.0,15],
["Josh Hazlewood","AUS",50,20,5.0,80.0,65,21.5,7.6,10],["Adil Rashid","ENG",130,300,10.0,120.0,130,22.0,7.6,20],
["Mohammad Amir","PAK",65,30,5.0,90.0,71,24.0,7.5,10],["Shadab Khan","PAK",115,900,14.0,130.0,120,22.5,7.7,25],
["Fakhar Zaman","PAK",85,2100,27.0,140.0,0,null,null,35],["Mohammad Hafeez","PAK",119,2514,26.3,122.0,61,22.5,7.0,40],
["Martin Guptill","NZ",122,3531,31.6,135.7,0,null,null,55],["Mitchell Santner","NZ",100,700,15.0,125.0,100,22.5,7.1,35]
];
export const S=[
 {k:2,l:"Matches",hi:1},{k:3,l:"Runs",hi:1},{k:4,l:"Batting avg",hi:1},{k:5,l:"Strike rate",hi:1},
 {k:6,l:"Wickets",hi:1},{k:7,l:"Bowling avg",hi:0},{k:8,l:"Economy",hi:0},{k:9,l:"Catches",hi:1}];

