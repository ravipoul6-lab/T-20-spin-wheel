import Peer from "peerjs";
import "./style.css";
import {RAW,S,val,show,score} from "./players.js";
const $=id=>document.getElementById(id);
const cv=$("wheel"),ctx=cv.getContext("2d");
const last=n=>n.split(" ").slice(-1)[0];
const NP=RAW.length,SP=["DOUBLE SPIN","SKIP +1","OPP SKIP -1","STEAL +1"];
const label=i=>i<NP?last(RAW[i][0]):SP[i-NP];
const blank=()=>({picks:{},dbl:null});
let db,uid,stRef,ST=null,FIN={X:null,Y:null},mine=blank(),seat=null,angle=0,animating=false,lastSpin=null,curGame=null,wroteFinal=false,first=true,stealMode=false,doneSp=null;
const seen=new Set();
const fresh=seats=>({game:Date.now()+"-"+Math.floor(Math.random()*1e6),seats:seats||{X:null,Y:null},removed:[],turn:"X",spin:null,cnt:{X:0,Y:0},skips:{X:3,Y:3},steals:{X:1,Y:1},ready:{X:false,Y:false},steal:null,ev:"",over:false});
const remaining=()=>Array.from({length:NP+4},(_,i)=>i).filter(i=>!ST.removed.includes(i));
const better=(a,b,s)=>{const A=score(a,s),B=score(b,s);return A===B?0:((s.hi?A>B:A<B)?1:-1)};
const opp=k=>k==="X"?"Y":"X";
function note(t){const m=$("msg");m.style.display=t?"block":"none";m.textContent=t||""}
function put(o){ST=o;persist();send({t:"state",s:o});onState(o)}

function draw(){
 ctx.clearRect(0,0,840,840);if(!ST)return;
 const rem=remaining(),n=rem.length,c=420,r=412;if(!n)return;const st=2*Math.PI/n;
 rem.forEach((ri,i)=>{
  const a0=angle+i*st,sp=ri>=NP;ctx.beginPath();ctx.moveTo(c,c);ctx.arc(c,c,r,a0,a0+st);ctx.closePath();
  ctx.fillStyle=sp?(i%2?"#b8860b":"#111"):`hsl(${(ri*137.5)%360},55%,${i%2?40:48}%)`;ctx.fill();ctx.strokeStyle="rgba(255,255,255,.6)";ctx.lineWidth=2;ctx.stroke();
  ctx.save();ctx.translate(c,c);ctx.rotate(a0+st/2);ctx.textAlign="right";ctx.fillStyle="#fff";
  ctx.font=`700 ${n>45?17:n>30?19:n>22?21:n>14?26:32}px Archivo,sans-serif`;ctx.fillText((sp?"★ ":"")+label(ri),r-14,7);ctx.restore();
 });
 ctx.beginPath();ctx.arc(c,c,34,0,7);ctx.fillStyle=getComputedStyle(document.body).backgroundColor;ctx.fill();
}
function startSpin(sp,instant){
 const rem=remaining(),t=rem.indexOf(sp.idx);if(t<0)return;
 const st=2*Math.PI/rem.length,target=-Math.PI/2-(t+.5)*st+sp.jit*st*.7;
 if(instant){angle=target;animating=false;return}
 let end=target;const start=angle;while(end>start-12*Math.PI)end-=2*Math.PI;
 animating=true;const t0=performance.now(),dur=4200;
 (function f(now){const p=Math.min(1,(now-t0)/dur),e=1-Math.pow(1-p,4);angle=start+(end-start)*e;draw();
  if(p<1)requestAnimationFrame(f);else{angle=end;animating=false;render();special();}})(t0);
}
const mkey=()=>"t20:"+room+":"+uid;
function persist(){if(isHost)try{localStorage.setItem("t20:"+room+":st",JSON.stringify(ST))}catch(e){}}
function loadMine(){try{const v=JSON.parse(localStorage.getItem(mkey()));mine=(v&&v.game===curGame)?{picks:v.picks||{},dbl:v.dbl==null?null:v.dbl}:blank()}catch(e){mine=blank()}render()}
function saveMine(){try{localStorage.setItem(mkey(),JSON.stringify({game:curGame,picks:mine.picks,dbl:mine.dbl}))}catch(e){}}

function onState(d){
 ST=d;seat=ST.seats.X===uid?"X":ST.seats.Y===uid?"Y":null;
 if(ST.game!==curGame){curGame=ST.game;wroteFinal=false;mine=blank();FIN={X:null,Y:null};doneSp=null;seen.clear();loadMine();}
 if(ST.spin&&ST.spin.id!==lastSpin){lastSpin=ST.spin.id;startSpin(ST.spin,first)}
 first=false;
 if(seat&&ST.steal){if(ST.steal.status==="req"&&ST.steal.by!==seat)handleSteal();else if(ST.steal.status==="done"&&ST.steal.by===seat)completeSteal();}
 special();
 if(ST.over&&seat&&!wroteFinal){wroteFinal=true;const f={game:ST.game,picks:mine.picks,dbl:mine.dbl};FIN[seat]=f;send({t:"final",k:seat,d:f});}
 render();if(!animating)draw();
}
const claim=()=>{};
async function setDbl(i){mine.dbl=i;await saveMine();put({...ST,ready:{...ST.ready,[seat]:true}})}
function doSpin(){
 if(!ST||animating||ST.spin||ST.steal||ST.over||seat!==ST.turn||!ST.ready.X||!ST.ready.Y)return;
 stealMode=false;const rem=remaining(),t=Math.floor(Math.random()*rem.length);
 put({...ST,ev:"",spin:{id:Date.now()+"-"+Math.floor(Math.random()*1e6),idx:rem[t],jit:Math.random()-.5,by:seat}});
}
function nextTurn(cnt){return cnt[opp(seat)]===8?seat:opp(seat)}
function finish(si){
 const sp=ST.spin,cnt={...ST.cnt},skips={...ST.skips};
 if(si!=null){mine.picks[si]=sp.idx;saveMine();cnt[seat]++}else skips[seat]--;
 const over=cnt.X===8&&cnt.Y===8;
 put({...ST,removed:[...ST.removed,sp.idx],spin:null,cnt,skips,over,turn:over?ST.turn:nextTurn(cnt),ev:`Player ${seat} ne ${si!=null?"ek stat lock kiya":"skip kiya"}`});
}
function special(){
 if(!ST||!seat||animating||!ST.spin||ST.spin.by!==seat||ST.spin.idx<NP||doneSp===ST.spin.id)return;
 doneSp=ST.spin.id;const k=ST.spin.idx-NP,o=opp(seat),skips={...ST.skips},steals={...ST.steals};
 let turn=nextTurn(ST.cnt);
 if(k===0)turn=seat;if(k===1)skips[seat]++;if(k===2)skips[o]=Math.max(0,skips[o]-1);if(k===3)steals[seat]++;
 put({...ST,removed:[...ST.removed,ST.spin.idx],spin:null,skips,steals,turn,ev:`Player ${seat}: ${SP[k]}${k===0?" - dobara spin!":""}`});
}
function reqSteal(slot){
 stealMode=false;
 put({...ST,steals:{...ST.steals,[seat]:ST.steals[seat]-1},steal:{id:Date.now()+"",by:seat,slot,status:"req",idx:null},ev:`Player ${seat} ne steal try kiya`});
}
function handleSteal(){
 const s=ST.steal;if(seen.has(s.id))return;seen.add(s.id);
 const idx=mine.picks[s.slot],cnt={...ST.cnt};
 if(idx!=null){delete mine.picks[s.slot];saveMine();cnt[seat]--}
 put({...ST,cnt,steal:{...s,status:"done",idx:idx==null?null:idx},ev:idx==null?`Steal fail: Player ${seat} ka ${S[s.slot].l} slot khaali tha`:`Steal safal! Player ${s.by} ne Player ${seat} ka ${S[s.slot].l} slot chheen liya`});
}
function completeSteal(){
 const s=ST.steal;if(seen.has(s.id))return;seen.add(s.id);
 const cnt={...ST.cnt};if(s.idx!=null){mine.picks[s.slot]=s.idx;saveMine();cnt[seat]++}
 put({...ST,cnt,steal:null,turn:cnt[seat]===8?opp(seat):ST.turn});
}
function newGame(){put(fresh(ST?ST.seats:null))}
function pts(){let x=0,y=0;S.forEach((s,i)=>{const c=better(RAW[FIN.X.picks[i]],RAW[FIN.Y.picks[i]],s);if(c>0)x+=FIN.X.dbl===i?2:1;else if(c<0)y+=FIN.Y.dbl===i?2:1});return[x,y]}

function render(){
 if(!ST){$("turn").textContent="Game load ho raha hai…";$("pick").innerHTML="";return}
 const both=ST.seats.X&&ST.seats.Y,fin=FIN.X&&FIN.Y&&FIN.X.game===ST.game&&FIN.Y.game===ST.game;
 $("turn").innerHTML=(ST.over?"Game khatam":both?`Baari: <span class="t${ST.turn.toLowerCase()}">Player ${ST.turn}</span>${seat===ST.turn?" (aap)":""}`:"Players ka intezaar")+(ST.ev?`<div class="hint" style="font-weight:400;font-size:14px">${ST.ev}</div>`:"");
 $("left").textContent=`Wheel me ${remaining().length} items · Skip: X ${ST.skips.X}, Y ${ST.skips.Y} · Steal: X ${ST.steals.X}, Y ${ST.steals.Y}`;
 $("spin").disabled=!(both&&ST.ready.X&&ST.ready.Y&&!ST.over&&!ST.spin&&!ST.steal&&!animating&&seat===ST.turn);
 const pk=$("pick");
 if(!seat&&!both){
  pk.innerHTML=`<div class="pname">Seat chuniye</div><p class="hint">Ek seat lene par wo aapki ho jati hai. Doosra player is link ko khol ke doosri seat lega.</p>`+
   ["X","Y"].map(k=>ST.seats[k]?"":`<button class="reset" data-k="${k}" style="margin-right:8px">Player ${k} banunga</button>`).join("");
  pk.querySelectorAll("button").forEach(b=>b.onclick=()=>claim(b.dataset.k));
 }else if(!seat){pk.innerHTML=`<p class="hint">Dono seat bhar chuki hain. Aap sirf dekh sakte hain.</p>`}
 else if(ST.over){
  if(!fin)pk.innerHTML=`<div class="pname">Result aa raha hai…</div><p class="hint">Doosre player ke stats reveal hone ka intezaar.</p>`;
  else{const[x,y]=pts();pk.innerHTML=`<div class="pname">${x===y?"Draw!":x>y?"Player X jeeta!":"Player Y jeeta!"}</div><p class="pmeta">Points: X ${x} · Y ${y} (2x slot me jeetne par 2 point)</p><button class="reset" id="ng">Naya game</button>`;$("ng").onclick=newGame}
 }else if(!both)pk.innerHTML=`<div class="pname">Aap Player ${seat} hain</div><p class="hint">Doosre player ko ye page ka link bhejiye aur uske seat lene ka intezaar kijiye.</p>`;
 else if(!ST.ready[seat]){
  pk.innerHTML=`<div class="pname">Apna 2x stat chuniye</div><p class="pmeta">Secret hai. Is stat me jeete to 2 point milenge.</p><div class="stats">`+S.map((s,i)=>`<button class="stat" data-i="${i}"><b style="font-size:16px">${s.l}</b></button>`).join("")+`</div>`;
  pk.querySelectorAll(".stat").forEach(b=>b.onclick=()=>setDbl(+b.dataset.i));
 }else if(!ST.ready[opp(seat)])pk.innerHTML=`<p class="hint">Doosra player apna 2x stat chun raha hai…</p>`;
 else if(ST.spin&&ST.spin.by===seat&&ST.spin.idx<NP&&!animating){
  const p=RAW[ST.spin.idx];
  pk.innerHTML=`<div class="pname">${p[0]}</div><div class="pmeta">${p[1]} · ek stat chuniye ya skip kijiye (doosre ko ye nahi dikhega)</div><div class="stats">`+
   S.map((s,i)=>`<button class="stat" data-i="${i}" ${mine.picks[i]!=null?"disabled":""}><span>${s.l}${mine.dbl===i?" ★2x":""}</span><b>${show(p,s)}</b></button>`).join("")+
   `</div><button class="reset" id="sk" ${ST.skips[seat]<1?"disabled":""}>Skip (${ST.skips[seat]} bache)</button>`;
  pk.querySelectorAll(".stat").forEach(b=>b.onclick=()=>finish(+b.dataset.i));$("sk").onclick=()=>finish(null);
 }else{
  let t;
  if(animating)t="Wheel ghoom raha hai…";
  else if(ST.steal)t=ST.steal.by===seat?"Steal ka jawab aa raha hai…":"Steal request process ho rahi hai…";
  else if(ST.spin)t=ST.spin.idx>=NP?`Special segment: ${SP[ST.spin.idx-NP]}`:`Player ${ST.spin.by} stat chun raha hai…`;
  else t=ST.turn===seat?"Aapki baari, SPIN dabaiye.":`Player ${ST.turn} ki baari hai.`;
  pk.innerHTML=`<div class="pname">Aap Player ${seat}</div><p class="hint">${t}</p>`;
  if(!animating&&!ST.spin&&!ST.steal&&ST.turn===seat&&ST.steals[seat]>0){
   if(!stealMode)pk.innerHTML+=`<button class="reset" id="st">Steal (${ST.steals[seat]})</button>`;
   else pk.innerHTML+=`<p class="pmeta">Opponent ka kaunsa stat slot chheenna hai? (jo slot aapka khaali hai)</p><div class="stats">`+S.map((s,i)=>`<button class="stat" data-i="${i}" ${mine.picks[i]!=null?"disabled":""}><b style="font-size:16px">${s.l}</b></button>`).join("")+`</div><button class="reset" id="sc">Cancel</button>`;
   const st=$("st");if(st)st.onclick=()=>{stealMode=true;render()};
   const sc=$("sc");if(sc)sc.onclick=()=>{stealMode=false;render()};
   pk.querySelectorAll(".stat").forEach(b=>b.onclick=()=>reqSteal(+b.dataset.i));
  }
 }
 let h=`<tr><th>Stat</th><th class="tx">Player X</th><th class="ty">Player Y</th></tr>`;
 const cell=(k,i,cl,w)=>{let p=null,d=false;if(fin){p=RAW[FIN[k].picks[i]];d=FIN[k].dbl===i}else if(k===seat&&mine.picks[i]!=null)p=RAW[mine.picks[i]];
  return p?`<td class="${cl} ${w}">${last(p[0])} <b>${show(p,S[i])}</b>${d?" ×2":""}</td>`:`<td class="hint">${fin||k===seat?"—":"🔒"}</td>`};
 S.forEach((s,i)=>{let wx="",wy="";if(fin){const c=better(RAW[FIN.X.picks[i]],RAW[FIN.Y.picks[i]],s);if(c>0)wx="win";else if(c<0)wy="win"}
  h+=`<tr><td>${s.l}${!fin&&mine.dbl===i?" ★2x":""}</td>${cell("X",i,"tx",wx)}${cell("Y",i,"ty",wy)}</tr>`});
 $("board").innerHTML=h;
 $("bh").textContent=fin?"Bowling avg aur economy me kam value behtar. Stats approximate hain.":`Locked stats: X ${ST.cnt.X}/8 · Y ${ST.cnt.Y}/8. Doosre ke stats aur 2x slot game ke ant me khulenge.`;
}
$("spin").onclick=doSpin;

let peer,conn,isHost=false,room="";
const rand=()=>Array.from({length:5},()=>"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Math.floor(Math.random()*32)]).join("");
function send(m){if(conn&&conn.open)conn.send(m)}
function wire(c){
 c.on("data",m=>{if(m.t==="state")onState(m.s);else if(m.t==="final"){FIN[m.k]=m.d;render()}});
 c.on("close",()=>note("Doosra player disconnect ho gaya. Wo wapas judega to game wahin se chalega."));
}
function showGame(){$("lobby").style.display="none";$("game").style.display="";}
function shareLink(){
 const url=location.origin+location.pathname+"?room="+room,sh=$("share");sh.style.display="block";
 sh.innerHTML=`<div class="pmeta">Doosre player ko ye link bhejiye (room ${room}):</div><div class="link"><input readonly value="${url}"><button class="reset" style="margin:0" id="cp">Copy</button></div>`;
 $("cp").onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(url);$("cp").textContent="Copied"};
}
function startHost(code){
 isHost=true;room=code;uid="h";localStorage.setItem("t20:host",code);
 peer=new Peer("t20w-"+code);
 peer.on("error",e=>{if(e.type==="unavailable-id"){localStorage.removeItem("t20:host");startHost(rand())}else note("Connection error: "+e.type)});
 peer.on("open",()=>{
  let saved=null;try{saved=JSON.parse(localStorage.getItem("t20:"+room+":st"))}catch(e){}
  first=true;onState(saved||fresh({X:"h",Y:null}));persist();showGame();shareLink();
 });
 peer.on("connection",c=>{
  if(conn&&conn.open){c.close();return}
  conn=c;wire(c);
  c.on("open",()=>{note("");if(!ST.seats.Y)put({...ST,seats:{...ST.seats,Y:"g"}});else send({t:"state",s:ST});if(wroteFinal&&FIN[seat])send({t:"final",k:seat,d:FIN[seat]})});
 });
}
function startGuest(code){
 room=code.toUpperCase();uid="g";peer=new Peer();
 peer.on("open",()=>{conn=peer.connect("t20w-"+room,{reliable:true});wire(conn);conn.on("open",()=>{showGame();note("")})});
 peer.on("error",e=>note(e.type==="peer-unavailable"?"Ye room nahi mila. Host ka page khula hona chahiye.":"Connection error: "+e.type));
}
(function init(){
 const q=new URLSearchParams(location.search).get("room"),saved=localStorage.getItem("t20:host"),b=$("lbtn");
 if(q){$("lb").textContent="Room "+q.toUpperCase()+" se judh raha hoon…";startGuest(q);return}
 $("lb").textContent="Naya room banao aur link doosre player ko bhejo. Dono alag device par khel sakte hain.";
 b.innerHTML=`<button class="reset" id="nr">Naya room banao</button> `+(saved?`<button class="reset" id="rr">Room ${saved} resume karo</button>`:"");
 $("nr").onclick=()=>{b.innerHTML="";$("lb").textContent="Room ban raha hai…";startHost(rand())};
 const rr=$("rr");if(rr)rr.onclick=()=>{b.innerHTML="";startHost(saved)};
})();
